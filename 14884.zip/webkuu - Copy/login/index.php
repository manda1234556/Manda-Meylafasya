<!DOCTYPE html>
<html>
	<head>

		<title>index login dan register</title>
	</head>
	<body>
		<form class="" action="login.php" method="post">
			<table>
				<tr>
					<td>username</td>
					<td><input type="text" name="username" value=""></td>
				</tr>
				<tr>
					<td>password</td>
					<td><input type="password" name="password" value=""></td>
				</tr>
				<tr>
					<td><a href="register.php">Belum Daftar</a>></td>
					<td><input type="submit" name="submit" value="submit"></td>
				</tr>
			</table>
		</form>

	</body>
</html>