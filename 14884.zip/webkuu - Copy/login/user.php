<?php 
include 'db.php';
session_start();
if (!isset($_SESSION['username'])) {
	header("Location: index.php?acces_denide");
}

 ?>

<!DOCTYPE html>
<html>
	<head>
	<title>Berhasil</title>
	</head>
	<body>
		<h1>Berhasil Login</h1>
		<?php echo $_SESSION['username']; ?>
		<a href="logout.php">Keluar</a>
	</body>
</html>