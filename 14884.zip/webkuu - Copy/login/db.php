<?php
$h='localhost';
$u='root';
$p='';
$db='webkuu';

$connect=new mysqli($h  , $u  ,$p,  $db);
if ($connect->connect_erorr)  {
	 echo "gagal";
}



?>