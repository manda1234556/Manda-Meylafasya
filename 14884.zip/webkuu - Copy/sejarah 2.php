<?php?>
<!DOCTYPE html>
<html>
<head>
	<title>ARTIKEL </title>
</head>
<body>

</body>
</html>
<body>
<div id="header">
<h1>ARTIKEL</h1>
</div>

<div id="nav">
<p>Desa Kalibenda adalah sebuah desa yang bertempat di kecamatan sigaluh kabupaten
Banjarnegara.Dahulu ada sebuah sungai di daerah hutan yang tidak jauh dari pemukiman warga
sungai tersebut biasa di pakai oleh warga setempat untuk mandi,mencuci pakaian dan
untuk keperluan lainya pada sutu hari saat orang-orang yang biasa mandi,mencuci pakaian
di sungai tersebut salah satu dari mereka melihat banyak benda-benda yang hanyut di sungai
tersebut mereka bertanya-tanya darimana datang benda-benda yang hanyut di sungai
dan ketua RT menamainya sebagai kalibenda (kali yang berarti sungai Benda adalah benda yang
hanyut di sungai tersebut</p>
</div>
<div id="footer">
</div>
</body>
</html>