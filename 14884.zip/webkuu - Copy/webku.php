<?php ?>
<!DOCTYPE HTML>
<html>
<head>
<style>
#header {
    background-color:Red;
    color:white;
    text-align:center;
    padding:5px;
}
#nav {
    line-height:30px;
    background-color:#eeeeee;
    height:300px;
    width:100px;
    float:left;
    padding:5px;	      
}
#section {
    width:350px;
    float:left;
    padding:10px;	 	 
}
#footer {
    background-color:Red;
    color:white;
    clear:both;
    text-align:center;
   padding:5px;	 	 
}
</style>
</head>
<body>

<div id="header">
<h1><marquee>SELAMAT DATANG DI WEB DESA KALIBENDA</marquee></h1>
</div>

<div id="nav">
<li><a href="../webkuu/sejarah 2.php">Sejarah</a><br/>
<li><a href="../webkuu/profil.php">Profil</a><br/>


</div>

<div id="section">
<h2>Website</h2>
<p>welcome di website ini website ini saya buat dengan tujuan untuk tugas design grafi</p>

</div>

<div id="footer">
TERIMA KASIH TELAH MENGUNJUNGI WEBSITE SAYA
</div>

</body>


</html>
