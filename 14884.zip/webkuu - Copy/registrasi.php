<?php
require 'function.php';

if(isset($_POST["submit"])) {

  if(tambah($_POST) > 0 ) {
    echo "<script
          alert('user baru berhasil ditambahkan!!!');
          document.location.href='login.php'
          </script>
          ";
  }else {
    echo "
    <script>
      alert('Anda kurang beruntung coba lagi!!!');
      document.location.href='login.php'
      </script>
      ";
  }
}

 ?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Halaman Registrasi</title>
    <style>
        label{
          display: block;
        }
    </style>
  </head>
  <link rel="stylesheet" href="css/styletambah.css"

  <body>

    <h1>Halaman Registrasi</h1>

    <form action="" method="post">

<ul>
    <li>
      <label for="username">username:</label>
      <input type="text" name="username" id="username">
    </li>
    <li>
      <label for="password">password:</label>
      <input type="password" name="password" id="password">
    </li>
    <li>
      <label for="password2">konfirmasi password:</label>
      <input type="password" name="password2" id="password2">
</li>
<li>
  <button type="submit" name="register">Register!</button>
</li>

</ul>

    </form>

  </body>
  </html>
