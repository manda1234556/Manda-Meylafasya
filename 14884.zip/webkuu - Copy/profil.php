<?php?>
<html>
<head>
<title><center><big><b>BIODATA</center></big></b></title>
<b>
<style>
title[
color :white;
}
</style>
</head>
<hr>
<body bgcolor='black'text='white'>
<font face=Comic Sans MS/>
<p>
<img src="_DSCO515" style="widht:150px; display:block;margin:auto">
<br> Nama Lengkap     :Manda Meylafasya
<br> Alamat           :Bantarsari RT03/02
<br> T.T.L            :Banjarnegara 07 Mei 2002
<br> Sekolah          :SMK N 1 BAWANG
<br> Kelas            :X RPL 1
</body>
</html>